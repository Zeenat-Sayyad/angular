import { Component } from "@angular/core";


@Component({
    selector:'ass-app',
    templateUrl:'./assignment.com.html',
    styleUrls:['./assignment.com.css']
})

export class myAssignment{
emp:any[];
new:any
pid:any;
pname:any;
des:any;
qty:any;
rate:any;
dis:any;
i:any=0;
flag = false;
alert:any;
constructor(){
    this.emp=[
{
    pid:101,pname:'lays',description:'1kg per pack',qty:3,rate:100,dis:0,index:this.i=this.i+1
},
{
    pid:102,pname:'kurkure',description:'2kg per pack',qty:3,rate:100,dis:0,index:this.i=this.i+1
},
{
    pid:103,pname:'banana chips',description:'2kg per pack',qty:1,rate:70,dis:0.15,index:this.i=this.i+1
},
{
    pid:104,pname:'lichees',description:'2kg per pack',qty:2,rate:150,dis:0.50,index:this.i=this.i+1
}

    ]
    this.new=[{}]
}
add(){
    var pr:number
   for(let i=0;i<this.emp.length;i++){
       if(this.pid==this.emp[i].pid){
        pr=1;
       }
       }
  
   if(pr==1)
   {
       this.alert="PID already present"
   }
   else if(this.pid==null){this.alert="Enter the PID"}
   else{
    this.emp.push({pid:this.pid,pname:this.pname,description:this.des,qty:this.qty,
       rate:this.rate,dis:this.dis,index:this.i=this.i+1})
       
    
    this.alert="Registered Successfully";
    
    
  this.clear();
   }
    }
update(){
    for (let o = 0; o < this.emp.length; o++) {
      
    
        if(this.pid==this.emp[o].pid){
            
            this.emp[o].pname=this.pname
            this.emp[o].description=this.des
            this.emp[o].qty=this.qty
            this.emp[o].rate=this.rate
            this.emp[o].dis=this.dis
        }
      }
      this.clear();
}
edit( p:any)
{
    for(let i=0;i<this.emp.length;i++){
        if(this.emp[i].pid==p){
this.pid=this.emp[i].pid;
this.pname=this.emp[i].pname;
this.des=this.emp[i].description;
this.qty=this.emp[i].qty;
this.rate=this.emp[i].rate;
this.dis=this.emp[i].dis;
this.flag = true;
        }
    }
}
delete(p:any){
    for(let i=0;i<this.emp.length;i++)
    {
                if(this.emp[i].pid==p)
                  {
                    this.emp.splice(i,1);
                  }
     }
                
}

clear(){
    this.pid=null
this.pname=null
this.des=null
this.qty=null
this.rate=null
this.dis=null
this.flag =false
}
}

