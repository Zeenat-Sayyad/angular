import {Component, OnInit, OnDestroy} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'componentC',
  template: 
     `<div id="menu">
        <header><h3>C</h3></header>
       
      </div> 
     `,
   styles: [
     'header {height: 30px; background-color: silver}',
     '#menu { float: left; width: 20%; background-color:lime;text-align:center }'
   ]
})

export default class ComponentC  {
 
}