import {Component, OnInit, OnDestroy} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'componentD',
  template: 
     `<div id="menu">
        <header><h3>D</h3></header>
        
      </div> 
     `,
   styles: [
     'header {height: 30px; background-color: silver}',
     '#menu { float: left; width: 20%; background-color:aqua;text-align:center }'
   ]
})

export default class ComponentD {
 
}