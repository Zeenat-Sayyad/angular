import {Component, OnInit, OnDestroy} from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'componentE',
  template: 
     `<div id="menu">
        <header><h3>E</h3></header>
      </div> 
      <div id="content">The End</div>`,
   styles: [
     'header {height: 30px; background-color: silver}',
     '#menu { float: left; width: 20%; background-color: orange ;text-align:center}',
     '#content { float: left; width: 20%; background-color: orange }'
   ]
})

export default class ComponentE {
 
}