import { Component } from "@angular/core";

@Component({
    selector:'one-way',
    templateUrl:'./oneway.com.html',
    styleUrls:['./oneway.com.css']
})

export class Oneway{
    flag = true;
    website={
        name:"AMP Developer",
        url:'https://www.google.com',
        logo:'favicon.ico',
        des:'this is description of site'

    };

} 