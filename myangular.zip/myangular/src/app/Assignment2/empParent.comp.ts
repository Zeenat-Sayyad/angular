import { Component } from "@angular/core";

@Component({
    selector:'emp-parent',
templateUrl:'./empParent.comp.html'
})

export class EmpParent {
    input:any;
}