import { Component, Input } from "@angular/core";


@Component({
    selector:'emp-child',
templateUrl:'./empChild.comp.html'
})

export class Empchild {
   @Input() in:any;
   Emp:any=[];
   temp:any=[];
   constructor(){
       this.Emp=[{Eid:101,Ename:'mayur',Esalary:2000},{Eid:102,Ename:'ajit',Esalary:15000},
       {Eid:103,Ename:'akshay',Esalary:20000},{Eid:104,Ename:'ajit',Esalary:2000}]
      
   }

   search(){
       this.temp=[];
       var o=0
       for(let i=0;i<this.Emp.length;i++){
           if(this.Emp[i].Ename==this.in)
           {  
               this.temp[o]=this.Emp[i];
               o++;
              
           }
       }
    
    }
   
}