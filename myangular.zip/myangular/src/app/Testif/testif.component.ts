import { Component } from "@angular/core";



@Component({
    selector: 'testif-app',
    templateUrl: './testif.component.html',
    styleUrls: ['./testif.component.css'] 
})
export class TestifComp{
    status:boolean=true;
    appTitle="Welcome to"
}