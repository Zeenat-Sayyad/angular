import { Component } from "@angular/core";
import { HttpClient, HttpParams, HttpResponseBase } from "@angular/common/http";


@Component({
    selector:'myhttp-app',
    template:`
    <div class="row">
    <div class="m-t-1">
        <button class="btn btn-primary" (click)="doGET()">GET</button>
        <button class="btn btn-primary" (click)="doPOST()">POST</button>
        <button class="btn btn-primary" (click)="doPUT()">PUT</button>
        <button class="btn btn-primary" (click)="doDELETE()">DELETE</button>
      </div>
  </div>
    
    `
})

export class MyHttpDemo{
    apiRoot:string = "https://httpbin.org";
    constructor(private http:HttpClient){}

    doGET(){
        console.log("GET")
    let url=`${this.apiRoot}/get`
    const httpOptions={
      params:new HttpParams().set("hii","bye").set("limit","25")
    }
    this.http.get(url,httpOptions).subscribe(res=>console.log(res))
    }
    doPOST(){
        console.log("POST")
        let url=`${this.apiRoot}/post`
        const httpOptions={
            params:new HttpParams().set("post","call").set("id","104")
        }
        this.http.post(url,{yoo:"raju",goo:"kaju"},httpOptions)
        .subscribe(res=>console.log(res))
    }
    doPUT(){
        console.log("put")
        let url=`${this.apiRoot}/put`
        const httpOptions={
            params:new HttpParams().set("put","call").set("id","104")
        }
        this.http.put(url,{yoo:"raju",goo:"kaju"},httpOptions)
        .subscribe(res=>console.log(res))
    }
    doDELETE(){
        console.log("delete")
        let url=`${this.apiRoot}/delete`
        const httpOptions={
            params:new HttpParams().set("delete","call")
        }
        this.http.delete(url,httpOptions)
        .subscribe(res=>console.log(res))
    }
}