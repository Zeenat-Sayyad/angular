import {MyService} from './my.service';
import { Component,OnInit } from '@angular/core';

@Component({
  selector: 'nest-service',
  template:`<Div><p>nested Service result</p>
  <p>{{msg}}</p></Div>` 
 })
export class NestedServiceComponent implements OnInit {
  msg:string;

  constructor(private mserv: MyService) { }

  ngOnInit() {this.msg=this.mserv.GetTextFromOtherService();}
}