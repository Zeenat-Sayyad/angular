import { Component } from "@angular/core";
import { SearchService } from "./searchser.service";

@Component({
    selector: 'app-search',
    template: `
  <form class="form-inline" style="margin-left:38%;">
    <div class="form-group">
      <input type="search"
             class="form-control"
             placeholder="Enter search string"
             #search>
    </div>
    <button class="btn btn-primary "
            (click)="doSearch(search.value)"> # (2)
            Search
    </button>
  </form>
  <div class="text-center">
  <p class="lead" *ngIf="loading">Loading...</p>
  </div>
  <ul class="list-group mx-auto">
  <li class="list-group-item "
      *ngFor="let track of itunes.results;let i=index" [ngStyle]="{'background-color':i%2==0?'rgba(45, 52, 54,1)':'rgba(45, 52, 54,0.9)','color':'black'}">
   
      <img src="{{track.thumbnail}}">
    <a target="_blank"
       href="{{track.link}}">{{ track.name }}
    </a>
  </li>
</ul>
   `,
   styles:[`a{
    text-decoration:none;color:white;font-family: 'Kaushan Script', cursive;font-size:20px;
    padding-left:10px;
   }
   a:hover{
     opacity:1
   }
   ul{
     width:400px;
   }
   
   `]
  
})
export class SearchComponent
{
    private loading: boolean = false;
    constructor(private itunes:SearchService) { }

    doSearch(term:string) {
        this.loading = true;
       // this.itunes.search(term)
       this.itunes.search(term).then( () => this.loading = false)
    }

}