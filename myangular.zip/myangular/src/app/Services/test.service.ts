import { Injectable } from "@angular/core";

@Injectable()

export class TestService{
    public sayhello(){
        return "hello services"
    }
    course=["css","css3","Html","Angular","html5","Bootstrap","jQuery"]
    public getCourse(){
        return this.course
    }
}