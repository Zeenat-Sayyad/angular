import { Component } from "@angular/core";

@Component({
    selector:'cal-app',
    templateUrl:'./cal.com.html',
    styleUrls:['./cal.com.css']
})



export class Calculator{
 input:string;
 arr:string[]=[];
 
 fun1(n:string){
    this.arr.push(n);
    this.display();
  }
 delete(){
     this.arr.pop();
     this.display();
 }
 display()
 {
    var str=""
      for (const obj of this.arr) {
        str+=obj;
   }
   this.input=str;
 }
 eval(){
     this.input= eval(this.input);
     this.arr=[];
     this.arr.push(this.input)
 }
clear()
{
    this.arr=[];
    this.display();
}

}