import { Component } from "@angular/core";


@Component({
    selector:'testFor-app',
    templateUrl:'./testFor.component.html',
    styleUrls:['./testFor.component.css']
})
export class TestForComp{
    employees:any[];
constructor(){
    this.employees=[
        {
            code:'101',name:'Tom',gender:'Male',
            annualSalary:5500,dob:'25/6/1988',fulltime:true
        },
        {
            code:'102',name:'TomCrus',gender:'Male',
            annualSalary:6000,dob:'25/6/1999',fulltime:false
        },
        {
            code:'103',name:'Tomlane',gender:'Male',
            annualSalary:6000,dob:'25/6/1977',fulltime:true
        },
        {
            code:'104',name:'Tomy',gender:'Male',
            annualSalary:7000,dob:'25/6/100',fulltime:false
        }
    ]
}

}