import { Component } from "@angular/core";

@Component({
    selector:'sub-app',
    templateUrl: './Sub.component.html'
   
})
export class Sub{
title:string="Subline"
}