import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HelloComp } from './AllAboutComp/hello/hello.component';
import { ProductComp } from './AllAboutComp/product/product.component';
import { BooksComp } from './AllAboutComp/books/book.component';
import { myModule } from './myModule/wel.module';
import { Parent } from './NestedComponent/parent.component';
import { Child } from './NestedComponent/child.component';
import { TestifComp } from './Testif/testif.component';
import { TestForComp } from './TestFor/testFor.component';
import { TheSwitchComponent } from './TestSwitch/personList.component';
import { DemoAttrComponents } from './attrdemo/attrdemo.component';
import { HighlightDirective } from './customAttr&Pipe/highlight.directive';
import { TestPipes } from './customAttr&Pipe/testpipes';
import { ExponentialStrengthPipe, square, discount } from './customAttr&Pipe/exponential-strength.pipe';
import { PowerBoosterComponent } from './customAttr&Pipe/power-booster.component';
import { myAssignment } from './Assignment/assignment.com';
import { Oneway } from './Data-BindingDemo/One-way/oneway.com';
import { Twoway } from './Data-BindingDemo/Two-way/twoway.com';
import {FormsModule, ReactiveFormsModule} from '@angular/forms'
import { Calculator } from './calculator/cal.com';
import { AppChildComponent } from './InputDecorator/appchild.component';
import { MyAppParentComponent } from './InputDecorator/appparent.component';
import { EmpParent } from './Assignment2/empParent.comp';
import { Empchild } from './Assignment2/empChild.comp';
import { ChildOutput } from './OutputDecorator/childOutput.com';
import { ParentOutput } from './OutputDecorator/parentOutput.com';
import { CalchildComponent } from './Ass3(@Output-Calculator)/calchild.com';
import { CalparentComponent } from './Ass3(@Output-Calculator)/calparent.com';
import { ConatctFormComponent } from './contact-form-TemplateDriven/contact.component';
import { ModelContactComponent } from './ModelDriven-Form/modelContact.component';
import { ValidFormComponent } from './Validation/validForm.component';
import { MyChildModule } from './NestedRouting/myChild.module';
import { RoutingModule } from './Routing/Routung.module';
import Nestedrouting from './NestedRouting/app.routes';
import { TestService } from './Services/test.service';
import { mytestService } from './Services/testComp.comp';
import { OtherService } from './Services/other.service';
import { MyService } from './Services/my.service';
import { NestedServiceComponent } from './Services/nestedservice.component';
import { Observable } from 'rxjs';
import { ObservableDemo } from './Services/observabledemo.component';
import { HttpClientModule } from '@angular/common/http';
import { HttpDemo } from './Services/httpdemo.component';
import {  MyHttpDemo } from './Services/myHttpdemo.comp';
import { SearchComponent } from './Services/fetchingdatafromwebservice/serarchcom.component';
import { SearchService } from './Services/fetchingdatafromwebservice/searchser.service';







@NgModule({
  declarations: [
    AppComponent,
    HelloComp,
    ProductComp,
    BooksComp,
    Parent,Child,
    TestifComp,TestForComp,
    TheSwitchComponent,
    DemoAttrComponents,
    HighlightDirective,
    TestPipes,
    ExponentialStrengthPipe,
    PowerBoosterComponent,
    square,
    myAssignment,
    discount,
    Oneway,
    Twoway,
    Calculator,
    AppChildComponent
    ,MyAppParentComponent,
    EmpParent,Empchild,
    ChildOutput,ParentOutput,
    CalchildComponent,
    CalparentComponent,
    ConatctFormComponent,
    ModelContactComponent,
    ValidFormComponent,
    mytestService,
    NestedServiceComponent,
    ObservableDemo,HttpDemo,
    MyHttpDemo,
    SearchComponent,
  ],
  imports: [
    BrowserModule,myModule,
    FormsModule,ReactiveFormsModule,
    MyChildModule,RoutingModule,Nestedrouting,HttpClientModule
   
  ],
  providers: [TestService,OtherService,MyService,SearchService],
  bootstrap: [AppComponent]
})
export class AppModule { }
