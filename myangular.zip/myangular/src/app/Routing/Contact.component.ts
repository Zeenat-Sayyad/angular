import { Component } from "@angular/core";

@Component({
    template:`
          <h3>Welcome to Contact page</h3>
          <a routerLink="contact-child">child</a>
          <router-outlet></router-outlet>
    `
})
export class ContactComponent{

}