import { Component } from "@angular/core";
import { AppChildComponent } from "../InputDecorator/appchild.component";

@Component({
    template:`<h3>Hello, i am Conatct-child Component</h3>`
})
export class ContactChildComponent{
    
}