import { Component } from "@angular/core";

@Component({
    template:`
    <h3>Welcome To Home buddy</h3>
    `
})
export class HomeComponent{
    
} 