import { Component } from "@angular/core";

@Component({
    selector:'cal-parent',
    templateUrl:'./calparent.com.html'
})
 export class CalparentComponent{
    total:number; 
    show(total:number){
      this.total=total;
     }
 }