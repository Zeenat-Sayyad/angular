export class Contact {
    firstname: string;
    lastname: string;

    city: string
    street: string
    pincode: string

    
}

