import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  styles: [
    '#wrapper { width: 100%; background-color: #FFF; margin-left:auto; margin-right:auto;}',
    'header {height: 50px; background-color: silver}',
    '[id^="column"] { width: 100%; background-color: yellow }',
    'footer {clear:both; height: 50px; background-color: silver}',
  ]
})

export class AppComponent {
  title = 'MyAngular';
  cname:string="Amp Developers"
  ename:string="mayur fegade"
  eid:number=101
  esalary:number=20000
  eexp:number=2

  
}

