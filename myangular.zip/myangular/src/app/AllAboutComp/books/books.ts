export class books{
    bname:string
    bid:number
    bprice:number
    bwriter:string

    constructor(bname:string,bid:number,bprice:number,bwriter:string)
    {
   this.bname=bname
   this.bid=bid
    this.bprice=bprice
    this.bwriter=bwriter
    }
}