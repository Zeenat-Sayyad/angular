import { Component } from "@angular/core";
import { product } from "./product";

@Component({
    selector:'product-app',
    templateUrl: './product.component.html',
    styleUrls: ['./product.component.css']
})
export class ProductComp{
obj:product=null;
constructor()
{
    this.obj=new product(1,1221,"foody",300,15);
}
}