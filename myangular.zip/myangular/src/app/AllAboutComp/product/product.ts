

export class product
{
    pid:number;
    pno:number;
    pname:string;
    pprice:number;
    pdiscount:number;

    constructor(a:number,b:number,c:string,d:number,e:number)
    {
        this.pid=a;
        this.pno=b;
        this.pname=c;
        this.pprice=d;
        this.pdiscount=e;
    }
}
